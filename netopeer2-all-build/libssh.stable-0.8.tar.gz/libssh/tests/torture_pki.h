char *torture_pki_read_file(const char *filename);
int torture_read_one_line(const char *filename, char *buffer, size_t len);
size_t torture_pubkey_len(const char *pubkey);
