# Unit tests for Liberouter API

## Prequisites
The tests assume the API is running separately on 127.0.0.1:5555, the database is initialized and there is an admin user with username admin and password admin.
