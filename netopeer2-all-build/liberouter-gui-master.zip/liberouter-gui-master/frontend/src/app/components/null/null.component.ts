import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-null',
  templateUrl: './null.component.html',
  styleUrls: ['./null.component.scss']
})
export class NullComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
