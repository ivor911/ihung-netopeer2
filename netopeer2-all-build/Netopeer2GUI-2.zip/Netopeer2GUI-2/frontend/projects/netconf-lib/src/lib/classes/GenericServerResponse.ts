/**
 * Author: Jakub Man <xmanja00@stud.fit.vutbr.cz>
 *
 */
export class GenericServerResponse {
  success: boolean;
  code: number;
  message?: string;
}
