/**
 * Author: Jakub Man <xmanja00@stud.fit.vutbr.cz>
 */
export class Notification {
    id: number;
    title: string;
    time: string;
    deviceName: string;
    channel: string;
}
