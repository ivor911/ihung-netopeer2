/**
 * Author: Jakub Man <xmanja00@stud.fit.vutbr.cz>
 */
export class ProfileItem {
    id: string; // Device ID
    subscriptions: string[]; // Channel names
}
