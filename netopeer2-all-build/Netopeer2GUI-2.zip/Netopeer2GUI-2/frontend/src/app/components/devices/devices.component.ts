/**
 * Author: Jakub Man <xmanja00@stud.fit.vutbr.cz>
 * Container for the devices tab
 */
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'nc-devices',
    templateUrl: './devices.component.html',
    styleUrls: ['./devices.component.scss']
})
export class DevicesComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
