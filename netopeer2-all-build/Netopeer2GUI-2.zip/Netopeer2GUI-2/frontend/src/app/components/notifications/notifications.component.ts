/**
 * Author: Jakub Man <xmanja00@stud.fit.vutbr.cz>
 * Container for the notifications tab
 */
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'nc-devices',
    templateUrl: './notifications.component.html',
    styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit {

    constructor() { }

    ngOnInit() {
    }

}
